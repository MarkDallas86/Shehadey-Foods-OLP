# Action items

| Owner | Item | Status | Due |
|---|---|---|---|
| Orderful (Kelly) | Send meeting deck, summary notes, contacts | Open | |
| Mark | Mass upload trading partner list into Orderful | Open | |
| Mark | Schedule recurring weekly project call (Pacific-friendly) | Open | |
| Mark | Costco follow-up before end of week | Open | |
| Mark | Send requirements list + tracker to the group | Open | |
| Concurrent (John) | Stand up Concurrent-hosted SFTP (sandbox first) and share connection details | Open | |
| Shehadey (ERMS lead) | Flat file specs for all transaction types, incl. missing element definitions | Open | |
| Shehadey (ERMS lead + IT) | Representative 850 production files | Open | |
| Shehadey (ERMS lead) | Share SPS testing portal credentials | Open | |
| Shehadey (IT) | BizLink IPs, auth preference, folder layout for the Concurrent SFTP | Open | |
