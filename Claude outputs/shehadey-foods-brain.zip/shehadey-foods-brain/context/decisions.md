# Decisions

| Date | Decision | Source |
|---|---|---|
| 2026-10-09 | Concurrent leads the account (Tray iPaaS integration; Orderful doesn't do iPaaS) | Slack thread (Scott Shields, Isaiah) |
| 2026-10-13 | Start net new with Orderful ISA IDs | Kickoff |
| 2026-10-13 | Costco is the pilot trading partner | Kickoff |
| 2026-10-13 | Concurrent hosts the SFTP server; BizLink moves files to/from it | Kickoff follow-up (Adam). Note: Gemini notes said Adam would set up the server — Mark confirmed Concurrent hosts |
| 2026-10-13 | 852s configured for VMI partners via Park City Group | Kickoff notes |
