# Open questions

## SFTP / BizLink (Concurrent hosts)
- BizLink outbound IP addresses to whitelist?
- SSH key or password?
- One folder per plant, or shared? Separate sandbox and production folders?
- File naming, polling frequency, archive/error handling?
- Can BizLink send one file to two destinations (shadow test vs Aptean)?
- Can ERMS produce test files and keep test 850s out of production?

## Scope
- Is the 850 → ERMS flat file in Concurrent's scope (SOW)?
- Doc types: 17 in inventory vs ~7 priced. Do 820/812/864/824 go into ERMS or stay in Orderful?
- Does Tray produce both inbound formats (pipe-delimited and Park City fixed-width)?

## Costco pilot
- Which of the 4 relationships are in the pilot? How is the ASN data gap closed?
- SPS testing portal access (credentials to be shared by client).

## Net new ISA
- Who notifies each partner of the new ID, and in what order?
